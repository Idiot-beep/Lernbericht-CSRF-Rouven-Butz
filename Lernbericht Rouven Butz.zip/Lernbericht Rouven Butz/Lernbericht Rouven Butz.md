# Lern-Bericht
✍️ Dieser Auftrag wurde von mir alleine bearbeitet

## Einleitung

✍️ Ich habe den Auftrag zu Cross Site Request Forgery (LA_183_1014_SL-CSRF), mit Fokus auf den Test ob der Benutzer eingeloggt ist, bearbeitet.

## Was habe ich gelernt?

✍️ Ich habe gelernt, wie ich mit einem simplen .html Dokument teste, ob der Benutzer auf einer bestimmten Website eingeloggt ist.

## Beschreibung

✍️ Verwenden Sie drei verschiedene Medien, um zu zeigen, was Sie gelernt haben. Zum Beispiel:

* In diesem Auftrag versuchte ich auf meiner .html Seite ein Bild zu laden. Damit der Benutzer das nicht mitbekommt mach ich es 0 auf 0 Pixel gross. Dieses Bild kann nur geladen werden, wenn der Benutzer eingeloggt ist. Kommt jezt eine Fehlermeldung, weiss ich, dass er nicht eingeloggt ist und kann darauf mit einer js Befehle reagieren. Wenn ich das Bild jetzt aber laden kann, weiss ich, dass der Benutzer eingeloggt ist und ich kann wieder mit js Befehle weitergeben.

* Die Bilder "Bildschirmaufnahme1" und "Bildschirmaufnahme2" zeigen, wie eine solche Seite angibt, ob man in Moodle oder in der Insecure App eingelogt ist.

*   <!-- Hier wird ein leeres div ausgegeben -->
<div id="state-moodle"></div>
    <!-- Hier wird unser 0 auf 0 Pixel Bild aus dem Moodul 183 geladen. Wird dieses Bild nicht geladen, wird die onerror Funktion getriggert. Das Programm schreibt jetzt in den div mit der id="state-moodle", dass man nicht eingelogt ist. Die onload Funktion funktioniert gelich, gib aber, wen das Bild geladen werden konnte, aus, dass man in Moodle eingelogt ist. -->
<img onerror="$('#state-moodle').html('Nicht in Moodle eingeloggt')" onload="$('#state-moodle').html('In Moodle eingeloggt')" width="0" height="0" id="hackApp" src="https://moodle.bbbaden.ch/pluginfile.php/80455/course/section/9983/modul-183.jpg"/>

## Verifikation

✍️  Die Beschreibung wie das Vorgehen generell funkioniert zeigt, dass ich das Prinzip verstanden habe.
    Das Bild zeigt, dass ich das Prinzip anwenden kann.
    Der Codeschnipsel zeigt, dass ich das Beispiel nicht nur anwenden kann sondern auch verstanden habe.

# Reflektion zum Arbeitsprozess

👍 Ich hatte den Code schnell verstanden und konnte diesen auch Problemlos anwenden.

👎 Ich konnte die Insecure App nicht richtig laden. Ich konnte die Index Seite zwar öffnen, die Formatierung aus den .css Dateien wurde aber nicht angewandt und ich konnte mich nicht einloggen. Ich konnte also nicht wirklich testen, ob diese Methode auch mit der Insecure App funktionirert.

**VBV**: ✍️ Das grösste Problem war meine Inkompetenz, die Insecure App richtig zu öffnen. Da ich aber nicht plötzlich kompetent werden kann, würde ich gerne zukünftig meinen Code kürzer und besser verteilt dokumentien.
